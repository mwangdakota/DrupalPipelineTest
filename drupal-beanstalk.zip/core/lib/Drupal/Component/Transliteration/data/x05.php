<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x10 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x20 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x30 => NULL, 'A', 'B', 'G', 'D', 'E', 'Z', 'E', 'E', 'T`', 'Z', 'I', 'L', 'X', 'C', 'K',
  0x40 => 'H', 'J', 'G', 'C', 'M', 'Y', 'N', 'S', 'O', 'Ch`', 'P', 'J', 'R', 'S', 'V', 'T',
  0x50 => 'R', 'Ts`', 'W', 'P`', 'K`', 'O', 'F', NULL, NULL, '<', '\'', '/', '!', ',', '?', '.',
  0x60 => NULL, 'a', 'b', 'g', 'd', 'e', 'z', 'e', 'e', 't`', 'z', 'i', 'l', 'x', 'c', 'k',
  0x70 => 'h', 'j', 'g', 'c', 'm', 'y', 'n', 's', 'o', 'ch`', 'p', 'j', 'r', 's', 'v', 't',
  0x80 => 'r', 'ts`', 'w', 'p`', 'k`', 'o', 'f', 'ev', NULL, '.', '-', NULL, NULL, NULL, NULL, NULL,
  0x90 => NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xA0 => '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xB0 => '@', 'e', 'a', 'o', 'i', 'e', 'e', 'a', 'a', 'o', NULL, 'u', '\'', '', '', '',
  0xC0 => '', '', '', ':', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xD0 => '', 'b', 'g', 'd', 'h', 'w', 'z', 'h', 't', 'y', 'k', 'k', 'l', 'm', 'm', 'n',
  0xE0 => 'n', 's', '`', 'p', 'p', 'z', 'z', 'q', 'r', 's', 't', NULL, NULL, NULL, NULL, NULL,
  0xF0 => 'ww', 'wy', 'yy', '\'', '"', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
];
